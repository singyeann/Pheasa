import 'package:flutter/material.dart';
import 'package:pheasa_project/widgets/topic_button.dart';

class ReviewTopicCard extends StatelessWidget {
  final String title;
  final String date;
  final String time;
  final String description;
  final double progress;
  final Color color;
  final VoidCallback onPressed;
  final String imageAsset;
  final String status;
  final double? height;
  final double? width;

  const ReviewTopicCard({
    Key? key,
    required this.title,
    required this.date,
    required this.time,
    required this.description,
    required this.progress,
    required this.color,
    required this.onPressed,
    required this.imageAsset,
    required this.status,
    this.height,
    this.width,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return Container(
      width: width ?? double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        color: color,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Left Side: Text and Content
              Expanded(
                flex: 2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      title,
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        color: Theme.of(context).colorScheme.onPrimary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      description,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onPrimary.withOpacity(0.8),
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 8),
                    Text(
                      "$date · $time",
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onPrimary,
                      ),
                    ),
                    SizedBox(height: 8),
                    LinearProgressIndicator(
                      value: progress,
                      color: Theme.of(context).colorScheme.secondary,
                      backgroundColor:
                      Theme.of(context).colorScheme.onPrimary.withOpacity(0.2),
                    ),
                    SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.secondary,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        status,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Theme.of(context).colorScheme.onSecondary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    SizedBox(height: 8),
                    TopicButton(
                      text: "Review Now",
                      textColor: color,
                      onPressed: onPressed,
                    ),
                  ],
                ),
              ),
              // Right Side: Image
              Expanded(
                flex: 1,
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Image.asset(
                    imageAsset,
                    fit: BoxFit.contain,
                    height: screenWidth * 0.15,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
