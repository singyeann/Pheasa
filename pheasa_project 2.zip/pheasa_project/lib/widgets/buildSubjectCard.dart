import 'package:flutter/material.dart';

Widget buildSubjectCard(String subject, double percentage, String additionalMetric) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          subject,
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 8),
        // Linear Progress Bar for Progress
        Container(
          width: double.infinity,
          height: 20,
          child: LinearProgressIndicator(
            value: percentage, // Set the progress value
            backgroundColor: Colors.grey[200],
            color: Colors.blue, // Bar color
          ),
        ),
        SizedBox(height: 8),
        // Additional Metric for the Subject
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8.0),
          child: Container(
            padding: EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.green[100],
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.green, width: 2),
            ),
            child: Row(
              children: [
                Icon(Icons.check_circle, color: Colors.green),
                SizedBox(width: 10),
                Text(
                  additionalMetric,
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
          ),
        ),
      ],
    ),
  );
}
