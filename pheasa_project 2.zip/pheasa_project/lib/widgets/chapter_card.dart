import 'package:flutter/material.dart';

class ChapterCard extends StatelessWidget {
  final String chapterTitle;
  final VoidCallback onTap;

  ChapterCard({required this.chapterTitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      child: ListTile(
        title: Text(chapterTitle),
        trailing: Icon(Icons.arrow_forward),
        onTap: onTap,
      ),
    );
  }
}
