import 'package:flutter/material.dart';

class TopicButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  final Color? backgroundColor;
  final Color? textColor;
  final double? width;
  final double? height;
  final double? padding;

  TopicButton({
    Key? key,
    required this.text,
    required this.onPressed,
    this.backgroundColor = Colors.white, // Default indigo color
    this.textColor = const Color(0xff7684C0), // Default white text
    this.width, // Optional width
    this.height = 50, // Default height
    this.padding = 16, // Default padding
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(padding ?? 16), // Dynamic padding
      child: SizedBox(
        width: width ?? double.infinity, // Default to full width
        height: height, // Adjustable height
        child: ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: backgroundColor,
            foregroundColor: textColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8), // Rounded corners
            ),
          ),
          child: Text(
            text,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}
