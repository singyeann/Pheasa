import 'package:flutter/material.dart';
import 'package:pheasa_project/widgets/topic_button.dart';

class TopicCard extends StatelessWidget {
  final String title;
  final String date;
  final String time;
  final Color color;
  final VoidCallback onPressed;
  final String imageAsset; // Path to local image asset
  final double? height; // Optional dynamic height
  final double? width;  // Optional dynamic width

  const TopicCard({
    Key? key,
    required this.title,
    required this.date,
    required this.time,
    required this.color,
    required this.onPressed,
    required this.imageAsset, // Require local asset path
    this.height,
    this.width,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Get screen dimensions
    final screenWidth = MediaQuery.of(context).size.width;

    return Container(
      height: height ?? screenWidth * 0.4, // Default: 40% of screen width
      width: width ?? double.infinity,    // Default: full width
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        color: color,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              // Left side: Text content
              Expanded(
                flex: 2, // Allocate 2/3 space for the text
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        color: Theme.of(context).colorScheme.onPrimary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 16),
                    Text(
                      "$date\n$time",
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onPrimary,
                      ),
                    ),
                    const Spacer(), // Push the button to the bottom
                    TopicButton(
                      text: "Start Now",
                      textColor: color,
                      onPressed: onPressed,
                    ),
                  ],
                ),
              ),
              // Right side: Image/Logo
              Expanded(
                flex: 1, // Allocate 1/3 space for the image
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Image.asset(
                    imageAsset, // Use local asset
                    fit: BoxFit.contain, // Ensure the image scales properly
                    height: (height ?? screenWidth * 0.4) * 0.5, // 50% of card height
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
