import 'package:flutter/material.dart';

class FadeScalePageRoute extends PageRouteBuilder {
  final Widget page;

  FadeScalePageRoute({required this.page})
      : super(
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      const begin = 0.0;
      const end = 1.0;
      const curve = Curves.easeInOut;

      var fadeTween = Tween<double>(begin: begin, end: end).chain(CurveTween(curve: curve));
      var scaleTween = Tween<double>(begin: 0.9, end: 1.0).chain(CurveTween(curve: curve));

      return FadeTransition(
        opacity: animation.drive(fadeTween),
        child: ScaleTransition(
          scale: animation.drive(scaleTween),
          child: child,
        ),
      );
    },
  );
}


