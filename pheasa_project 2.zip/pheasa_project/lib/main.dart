import 'package:flutter/material.dart';
import 'pages/home.dart';
import 'pages/welcome.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Drawer App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        colorScheme: ColorScheme(
            brightness: Brightness.dark,
            primary: Color(0xff7684C0),
            onPrimary: Color(0xffffffff),
            secondary: Color(0xffF4A261),
            onSecondary: Color(0xffFFFFFF),
            error: Color(0xffF87171),
            onError: Color(0xfffee2e2),
            surface: Color(0xffDFF6FF),
            onSurface: Color(0xff020617),
        ),
        textTheme: TextTheme(
          titleLarge: TextStyle(fontFamily: 'Raleway', fontSize: 64, fontWeight: FontWeight.bold),
          labelSmall: TextStyle(fontFamily: 'Raleway', fontSize: 16),
          bodyLarge: TextStyle(fontFamily: 'Raleway', fontSize: 48),
          bodyMedium: TextStyle(fontFamily: 'Raleway', fontSize: 32),
          bodySmall: TextStyle(fontFamily:'Raleway', fontSize: 24),
        ),
        scaffoldBackgroundColor: Color(0xFFEFF6FF), // Set background to #EFF6FF
      ),
      home: Welcome(),
    );
  }
}
