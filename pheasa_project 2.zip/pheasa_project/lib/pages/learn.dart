import 'package:flutter/material.dart';
import 'quiz.dart'; // Import the ReviewModule page

class Learn extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Learn Page'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            // Navigate to the ReviewModule page
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Quiz()),
            );
          },
          child: Text('Go to Quiz to Advance'),
        ),
      ),
    );
  }
}
