import 'package:flutter/material.dart';

class ChapterReviewPage extends StatelessWidget {
  final String chapterTitle;

  ChapterReviewPage({required this.chapterTitle});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              chapterTitle,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Text(
              'This is where the content for $chapterTitle will go. You can add reading material, audio, or questions related to this chapter here.',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // Go back to the review module
              },
              child: Text('Go Back'),
            ),
          ],
        ),
      ),
    );
  }
}
