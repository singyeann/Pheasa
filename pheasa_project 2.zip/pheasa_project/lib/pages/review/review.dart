import 'package:flutter/material.dart';
import '../../widgets/bottom_nav_bar.dart';
import '../../widgets/pheasa_apppbar.dart';
import '../../widgets/review_topic_card.dart';
import 'review_module.dart';
class Review extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: ListView(
            // Ensures all content is scrollable
            physics: BouncingScrollPhysics(),
            children: [
              // Writing Card
              ReviewTopicCard(
                title: "Writing",
                date: "October 7, 2024",
                time: "09:00 am",
                description: "Review for Writing",
                progress: 0.2,
                status: "In Progress",
                color: Color(0xFF7684C0),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ReviewModule()),
                  );
                },
                imageAsset: 'assets/images/writing.png',
              ),
              SizedBox(height: 16),
              // Listening Card
              ReviewTopicCard(
                title: "Listening",
                date: "October 7, 2024",
                time: "09:00 am",
                description: "Review for Listening",
                progress: 0.4,
                status: "In Progress",
                color: Colors.amber,
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ReviewModule()),
                  );
                },
                imageAsset: 'assets/images/listening.png',
              ),
              SizedBox(height: 16),
              // Explore Now Button
              ElevatedButton(
                onPressed: () {
                  print("Explore Now clicked");
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF7684C0),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  minimumSize: Size(double.infinity, 50),
                ),
                child: Text("Explore Now"),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: CustomBottomNavBar(currentIndex: 1),
    );
  }
}
