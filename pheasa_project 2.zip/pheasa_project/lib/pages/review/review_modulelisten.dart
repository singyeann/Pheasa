import 'package:flutter/material.dart';
import '../../widgets/bottom_nav_bar.dart';
import 'review_page.dart'; // Import ChapterReviewPage
import '../../widgets/chapter_card.dart'; // Import ChapterCard component

class ReviewModule extends StatelessWidget {
  // List of chapters
  final List<String> chapters = [
    'Chapter 1: Introduction',
    'Chapter 2: Basics',
    'Chapter 3: Intermediate',
    'Chapter 4: Advanced',
    'Chapter 5: Expert',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: chapters.length,
        itemBuilder: (context, index) {
          return ChapterCard(
            chapterTitle: chapters[index],
            onTap: () {
              // Navigate to the specific chapter review page
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ChapterReviewPage(
                    chapterTitle: chapters[index],
                  ),
                ),
              );
            },
          );
        },
      ),
      bottomNavigationBar: CustomBottomNavBar(currentIndex: 1),
    );
  }
}
