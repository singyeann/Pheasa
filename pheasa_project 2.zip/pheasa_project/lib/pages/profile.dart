import 'package:flutter/material.dart';
import '../widgets/bottom_nav_bar.dart';
import '../widgets/buildSubjectCard.dart';
import '../widgets/pheasa_apppbar.dart';

class Profile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),

      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Profile Section
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  // Profile Picture
                  CircleAvatar(
                    radius: 50,
                    backgroundImage: AssetImage(
                        'assets/images/profp.jpg'), // Your image path
                  ),
                  SizedBox(height: 8),
                  // Name
                  Text(
                      'Reki Kyan',
                      style: Theme
                          .of(context)
                          .textTheme
                          .bodyMedium
                  ),
                  SizedBox(height: 4),
                  // Level
                  Text(
                      'Level: B1',
                      style: Theme
                          .of(context)
                          .textTheme
                          .bodySmall
                  ),
                  SizedBox(height: 4),
                  // Email
                  Text(
                    'Email: rekikyan@example.com',
                    style: Theme
                        .of(context)
                        .textTheme
                        .bodySmall,
                  ),
                  SizedBox(height: 24),
                  // Add some spacing before the progress section
                ],
              ),
            ),

            // Subject Progress Section
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Text(
                'Subject Progress',
                style: Theme
                    .of(context)
                    .textTheme
                    .bodyLarge
                    ?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Theme
                      .of(context)
                      .colorScheme
                      .primary,
                ),
              ),
            ),
            SizedBox(height: 16),

            // Progress Bars for Subject Percentages and Additional Metrics
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                buildSubjectCard(
                    'Listening', 0.75, 'Lessons Completed: 15/20'),
                buildSubjectCard('Reading', 0.60, 'Lessons Completed: 12/20'),
              ],
            ),

            // Achievements & Badges Section
            Padding(
              padding: const EdgeInsets.symmetric(
                  vertical: 8.0, horizontal: 16.0),
              child: Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.yellow[100],
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.orange, width: 2),
                ),
                child: Row(
                  children: [
                    Icon(Icons.star, color: Colors.orange),
                    SizedBox(width: 10),
                    Text('Achievement: Fast Learner Badge', style: Theme
                        .of(context)
                        .textTheme
                        .labelSmall),
                  ],
                ),
              ),
            ),

            // Upcoming Lessons Section
            Padding(
              padding: const EdgeInsets.symmetric(
                  vertical: 8.0, horizontal: 16.0),
              child: Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.blue[100],
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.blue, width: 2),
                ),
                child: Row(
                  children: [
                    Icon(Icons.schedule, color: Colors.blue),
                    SizedBox(width: 10),
                    Text('Upcoming Lesson: Grammar Review', style: Theme
                        .of(context)
                        .textTheme
                        .labelSmall),
                  ],
                ),
              ),
            ),

            // Leaderboard Section
            Padding(
              padding: const EdgeInsets.symmetric(
                  vertical: 8.0, horizontal: 16.0),
              child: Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.purple[100],
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.purple, width: 2),
                ),
                child: Row(
                  children: [
                    Icon(Icons.emoji_events, color: Colors.purple),
                    SizedBox(width: 10),
                    Text('Rank: 5th out of 50 in Reading', style: Theme
                        .of(context)
                        .textTheme
                        .labelSmall),
                  ],
                ),
              ),
            ),

            // Personalized Recommendations Section
            Padding(
              padding: const EdgeInsets.symmetric(
                  vertical: 8.0, horizontal: 16.0),
              child: Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.orange[100],
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.orange, width: 2),
                ),
                child: Row(
                  children: [
                    Icon(Icons.lightbulb, color: Colors.orange),
                    SizedBox(width: 10),
                    Text('Recommendation: Focus on Listening practice',
                        style: Theme
                            .of(context)
                            .textTheme
                            .labelSmall),
                  ],
                ),
              ),
            ),

            // Motivational Quotes Section
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.yellow[50],
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.yellow, width: 2),
                ),
                child: Text(
                  'Motivational Quote: “Everything you have ever wanted is sitting on the other side of fear."',
                  style: Theme
                      .of(context)
                      .textTheme
                      .labelSmall
                      ?.copyWith(fontStyle: FontStyle.italic),
                  textAlign: TextAlign.center,
                ),
              ),
            ),

            SizedBox(height: 24), // Add some spacing for any other metrics
          ],
        ),
      ),
      bottomNavigationBar: CustomBottomNavBar(currentIndex: 2),
    );
  }
}