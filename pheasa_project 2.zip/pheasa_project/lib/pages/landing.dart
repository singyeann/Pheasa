import 'package:flutter/material.dart';
import 'package:pheasa_project/widgets/bottom_nav_bar.dart';
import '../widgets/pheasa_apppbar.dart';
import '../widgets/topic_card.dart';
import 'learn.dart';

class Landing extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              // Speaking Card
              TopicCard(
                title: "Writing",
                date: "October 7, 2024",
                time: "09:00 am",
                color: Color(0xFF7684C0), // Indigo shade
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Learn()),
                  );
                },
                imageAsset: 'assets/images/writing.png',
              ),
              SizedBox(height: 16),

              // Listening Card
              TopicCard(
                title: "Listening",
                date: "October 7, 2024",
                time: "09:00 am",
                color: Colors.amber,
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Learn()),
                  );
                },
                imageAsset: "assets/images/listening.png",
              ),
              SizedBox(height: 16),

              // Explore Now Button
              ElevatedButton(
                onPressed: () {
                  print("Explore Now clicked");
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF7684C0),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  minimumSize: Size(double.infinity, 50),
                ),
                child: Text("Explore Now"),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: CustomBottomNavBar(currentIndex: 0),
    );
  }
}

