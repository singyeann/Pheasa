import 'package:flutter/material.dart';
import 'review/review.dart'; // Import the ReviewModule page

class Result extends StatelessWidget {
  final int score;
  final int total;

  Result({required this.score, required this.total});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Result Page'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Display the result score
            Text(
              'You scored $score out of $total',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            // Display a message based on the score
            Text(
              score == total
                  ? 'Perfect! You got everything right!'
                  : score > total / 2
                  ? 'Good job! You can do even better next time!'
                  : 'You failed, moron. Go review!',
              style: TextStyle(fontSize: 20, color: Colors.blueGrey),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 30),
            // Button to navigate to the Review page
            ElevatedButton(
              onPressed: () {
                // Navigate to the ReviewModule page
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Review()),
                );
              },
              child: Text('Go to Review'),
            ),
          ],
        ),
      ),
    );
  }
}
