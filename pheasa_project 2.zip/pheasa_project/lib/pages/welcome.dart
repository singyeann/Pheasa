import 'package:flutter/material.dart';
import '../widgets/transition_animation_fade.dart';
import 'landing.dart';

class Welcome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Center(child: Image.asset('assets/images/logo.png', width: 250, height: 250)),
            SizedBox(height:100),
            Text(
              'PHEASA',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                color: Theme.of(context).colorScheme.primary,
              ),

            ),
            Text(
              'Next Generation\nEducational platform',
              style: Theme.of(context).textTheme.bodySmall,

              textAlign: TextAlign.center,
            ),
            SizedBox(height: 100),
            ElevatedButton(
              onPressed: () {
                // Navigate to the Landing page
                Navigator.of(context).push(FadeScalePageRoute(page: Landing()));
              },
              style: ElevatedButton.styleFrom(
                minimumSize: Size(250, 80),
                backgroundColor: Color(0xff7684C0),
                foregroundColor: Color(0xffEFF6FF),
                elevation: 5, // Set shadow/elevation
                textStyle: TextStyle(fontSize: 24,fontWeight: FontWeight.bold, fontFamily: 'Raleway', color: Colors.white),
              ),
              child: Text(
                  'Explore Now',
                  style: TextStyle(fontSize: 24,fontWeight: FontWeight.bold, fontFamily: 'Raleway', color: Colors.white),

              ),
            ),
          ],
        ),
      ),
    );
  }
}
