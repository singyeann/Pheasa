import 'package:flutter/material.dart';
import 'result.dart'; // Import the ReviewModule page

class Quiz extends StatefulWidget {
  @override
  _QuizState createState() => _QuizState();
}

class _QuizState extends State<Quiz> {
  // List of questions and answer options
  final List<Map<String, dynamic>> _questions = [
    {
      'question': 'What is the capital of France?',
      'options': ['Berlin', 'Madrid', 'Paris', 'Rome'],
      'correctAnswer': 'Paris',
    },
    {
      'question': 'Which planet is known as the Red Planet?',
      'options': ['Earth', 'Mars', 'Jupiter', 'Saturn'],
      'correctAnswer': 'Mars',
    },
    {
      'question': 'Who wrote "Romeo and Juliet"?',
      'options': ['Shakespeare', 'Dickens', 'Hemingway', 'Austen'],
      'correctAnswer': 'Shakespeare',
    },
  ];

  // Keeps track of selected answers
  List<String?> _selectedAnswers = [];

  @override
  void initState() {
    super.initState();
    // Initialize _selectedAnswers with null values for each question
    _selectedAnswers = List.filled(_questions.length, null);
  }

  // Check if the answer is correct
  void _submitQuiz() {
    int score = 0;
    for (int i = 0; i < _questions.length; i++) {
      if (_selectedAnswers[i] == _questions[i]['correctAnswer']) {
        score++;
      }
    }

    // Navigate to the result page with the score
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Result(score: score, total: _questions.length),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Quiz Page'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Display the questions dynamically
            Expanded(
              child: ListView.builder(
                itemCount: _questions.length,
                itemBuilder: (context, index) {
                  final question = _questions[index];
                  return Card(
                    margin: EdgeInsets.symmetric(vertical: 8.0),
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            question['question'],
                            style:
                             Theme.of(context).textTheme.bodyMedium
                          ),
                          SizedBox(height: 8.0),
                          // Display options
                          ...List.generate(question['options'].length, (optionIndex) {
                            return RadioListTile<String>(
                              title: Text(question['options'][optionIndex]),
                              value: question['options'][optionIndex],
                              groupValue: _selectedAnswers[index],
                              onChanged: (value) {
                                setState(() {
                                  _selectedAnswers[index] = value;
                                });
                              },
                            );
                          }),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            // Submit button
            ElevatedButton(
              onPressed: _submitQuiz,
              child: Text('Submit Quiz'),
            ),
          ],
        ),
      ),
    );
  }
}
